import streamlit as st


def load_styles(light_mode: bool = False):
    if light_mode:
        theme = {
            "bg": "#f4f7fb",
            "surface": "rgba(255,255,255,.82)",
            "surface_strong": "#ffffff",
            "border": "rgba(15,23,42,.10)",
            "text": "#0f172a",
            "text_soft": "#334155",
            "muted": "#64748b",
            "input_bg": "#ffffff",
            "input_border": "#d7dee9",
            "input_text": "#0f172a",
            "input_placeholder": "#94a3b8",
            "cyan": "#0891b2",
            "blue": "#2563eb",
            "violet": "#7c3aed",
            "pink": "#db2777",
            "shadow": "rgba(15,23,42,.10)",
        }
    else:
        theme = {
            "bg": "#070b16",
            "surface": "rgba(16,24,43,.72)",
            "surface_strong": "rgba(20,30,53,.92)",
            "border": "rgba(148,163,184,.16)",
            "text": "#f8fafc",
            "text_soft": "#cbd5e1",
            "muted": "#94a3b8",
            "input_bg": "#111827",
            "input_border": "rgba(148,163,184,.20)",
            "input_text": "#f8fafc",
            "input_placeholder": "#64748b",
            "cyan": "#22d3ee",
            "blue": "#60a5fa",
            "violet": "#a78bfa",
            "pink": "#f472b6",
            "shadow": "rgba(0,0,0,.25)",
        }

    st.markdown(
        f"""
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

        <style>
        :root {{
            --bg: {theme['bg']};
            --surface: {theme['surface']};
            --surface-strong: {theme['surface_strong']};
            --border: {theme['border']};
            --text: {theme['text']};
            --text-soft: {theme['text_soft']};
            --muted: {theme['muted']};
            --input-bg: {theme['input_bg']};
            --input-border: {theme['input_border']};
            --input-text: {theme['input_text']};
            --input-placeholder: {theme['input_placeholder']};
            --cyan: {theme['cyan']};
            --blue: {theme['blue']};
            --violet: {theme['violet']};
            --pink: {theme['pink']};
            --shadow: {theme['shadow']};
            --radius: 22px;
        }}

        html {{ scroll-behavior: smooth; }}

        .stApp {{
            background:
                radial-gradient(circle at 10% 10%, color-mix(in srgb, var(--cyan) 12%, transparent), transparent 28%),
                radial-gradient(circle at 90% 20%, color-mix(in srgb, var(--violet) 14%, transparent), transparent 30%),
                radial-gradient(circle at 50% 90%, color-mix(in srgb, var(--pink) 8%, transparent), transparent 28%),
                var(--bg);
            color: var(--text);
            font-family: 'Inter', sans-serif;
            transition: background .35s ease, color .25s ease;
        }}

        [data-testid="stHeader"] {{ background: transparent; }}
        [data-testid="stToolbar"] {{ background: transparent; }}

        .block-container {{
            max-width: 1180px;
            padding-top: 1.2rem;
            padding-bottom: 3rem;
        }}

        /* Theme switch */
        .theme-switch-row {{
            display: flex;
            justify-content: flex-end;
            align-items: center;
            min-height: 38px;
            margin-bottom: .2rem;
        }}

        div[data-testid="stToggle"] {{
            display: flex;
            justify-content: flex-end;
        }}

        div[data-testid="stToggle"] label {{
            color: var(--muted) !important;
            font-size: .82rem !important;
            font-weight: 600 !important;
        }}

        .hero-card, .glass-card {{
            position: relative;
            overflow: hidden;
            background: linear-gradient(145deg, var(--surface-strong), var(--surface));
            border: 1px solid var(--border);
            border-radius: var(--radius);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            box-shadow: 0 20px 70px var(--shadow);
        }}

        .hero-card {{
            padding: 2.5rem;
            animation: reveal .8s ease both;
        }}

        .hero-card::before {{
            content: "";
            position: absolute;
            width: 280px;
            height: 280px;
            right: -100px;
            top: -120px;
            background: linear-gradient(135deg, var(--cyan), var(--violet), var(--pink));
            filter: blur(70px);
            opacity: .18;
            animation: floatGlow 7s ease-in-out infinite;
        }}

        .section-title {{
            margin: 3rem 0 1.2rem;
            animation: reveal .7s ease both;
        }}

        .section-title h2 {{
            color: var(--text);
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.8rem;
            margin: 0;
        }}

        .section-title p {{ color: var(--muted); margin-top: .35rem; }}

        .eyebrow {{
            color: var(--cyan);
            font-size: .78rem;
            font-weight: 800;
            letter-spacing: .16em;
            text-transform: uppercase;
        }}

        .hero-name {{
            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(2.7rem, 7vw, 5.4rem);
            line-height: .98;
            font-weight: 700;
            margin: .45rem 0 1rem;
            background: linear-gradient(90deg, var(--text), var(--cyan), var(--violet), var(--pink));
            background-size: 220% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: gradientText 7s linear infinite;
        }}

        .hero-role {{ color: var(--text-soft); font-size: 1.12rem; font-weight: 600; }}
        .hero-summary {{ max-width: 760px; color: var(--muted); line-height: 1.85; font-size: 1rem; }}

        .profile-image img {{
            border-radius: 20px;
            border: 1px solid var(--border);
            box-shadow: 0 20px 50px var(--shadow);
        }}

        .link-row {{ display: flex; flex-wrap: wrap; gap: .7rem; margin-top: 1.4rem; }}

        .icon-link {{
            display: inline-flex;
            align-items: center;
            gap: .55rem;
            padding: .72rem 1rem;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: rgba(255,255,255,.045);
            color: var(--text-soft) !important;
            text-decoration: none !important;
            transition: .25s ease;
        }}

        .icon-link:hover {{
            transform: translateY(-3px);
            border-color: color-mix(in srgb, var(--cyan) 55%, transparent);
            background: color-mix(in srgb, var(--cyan) 8%, transparent);
            box-shadow: 0 10px 25px color-mix(in srgb, var(--cyan) 10%, transparent);
        }}

        .stat-card {{
            padding: 1.35rem;
            min-height: 125px;
            transition: transform .3s ease, border-color .3s ease;
            animation: reveal .7s ease both;
        }}

        .stat-card:hover {{ transform: translateY(-6px); border-color: color-mix(in srgb, var(--blue) 38%, transparent); }}
        .stat-icon {{ font-size: 1.2rem; color: var(--cyan); margin-bottom: .7rem; }}
        .stat-label {{ color: var(--muted); font-size: .8rem; text-transform: uppercase; letter-spacing: .08em; }}
        .stat-value {{ color: var(--text); font-weight: 700; font-size: 1rem; margin-top: .35rem; }}

        .skill-card {{ padding: 1.5rem; min-height: 210px; transition: .3s ease; }}
        .skill-card:hover {{ transform: translateY(-5px); border-color: color-mix(in srgb, var(--violet) 40%, transparent); }}
        .skill-heading {{ display: flex; align-items: center; gap: .6rem; color: var(--text); font-weight: 700; margin-bottom: 1rem; }}
        .skill-heading i {{ color: var(--violet); }}

        .skill-pill {{
            display: inline-block;
            margin: .25rem;
            padding: .42rem .72rem;
            border-radius: 999px;
            font-size: .78rem;
            font-weight: 600;
            color: var(--text-soft);
            background: linear-gradient(135deg, color-mix(in srgb, var(--cyan) 10%, transparent), color-mix(in srgb, var(--violet) 12%, transparent));
            border: 1px solid var(--border);
            transition: .25s ease;
        }}

        .skill-pill:hover {{ transform: translateY(-2px) scale(1.03); border-color: color-mix(in srgb, var(--cyan) 40%, transparent); }}

        .timeline-card {{
            padding: 1.7rem;
            border-left: 3px solid transparent;
            border-image: linear-gradient(var(--cyan), var(--violet), var(--pink)) 1;
        }}

        .timeline-card h3, .project-body h3, .education-card h3 {{ color: var(--text); }}
        .experience-meta {{ color: var(--muted); font-size: .88rem; margin-bottom: 1rem; }}
        .experience-list {{ margin: 0; padding-left: 1.15rem; color: var(--text-soft); line-height: 1.8; }}

        .project-card {{ overflow: hidden; transition: transform .35s ease, box-shadow .35s ease, border-color .35s ease; }}
        .project-card:hover {{ transform: translateY(-8px); border-color: color-mix(in srgb, var(--cyan) 32%, transparent); box-shadow: 0 24px 60px var(--shadow); }}
        .project-image {{ width: 100%; height: 220px; object-fit: cover; display: block; filter: saturate(.9); transition: transform .6s ease, filter .6s ease; }}
        .project-card:hover .project-image {{ transform: scale(1.045); filter: saturate(1.15); }}
        .project-body {{ padding: 1.4rem; }}
        .project-role {{ color: var(--cyan); font-size: .82rem; font-weight: 700; margin-bottom: .7rem; }}
        .project-description {{ color: var(--muted); line-height: 1.7; }}

        .education-card {{ padding: 1.5rem; display: flex; gap: 1rem; align-items: center; height: 100%; }}
        .education-icon {{ width: 48px; height: 48px; display: grid; place-items: center; flex: 0 0 48px; border-radius: 14px; background: linear-gradient(135deg, color-mix(in srgb, var(--cyan) 15%, transparent), color-mix(in srgb, var(--violet) 18%, transparent)); color: var(--cyan); }}

        /* Contact section */
        div[data-testid="stVerticalBlockBorderWrapper"] {{
            background: linear-gradient(145deg, var(--surface-strong), var(--surface)) !important;
            border: 1px solid var(--border) !important;
            border-radius: var(--radius) !important;
            box-shadow: 0 20px 70px var(--shadow) !important;
            padding: .35rem !important;
            margin-top: 3rem;
        }}

        .contact-shell {{
            padding: 2rem;
            margin-top: 3rem;
        }}

        .contact-form {{
            margin-top: 1.25rem;
            padding: 0 !important;
            border: 0 !important;
            border-radius: 0 !important;
            background: transparent !important;
            box-shadow: none !important;
        }}

        .contact-form [data-testid="stFormSubmitButton"] {{ margin-top: .4rem; }}

        .contact-form input,
        .contact-form textarea,
        div[data-testid="stForm"] input,
        div[data-testid="stForm"] textarea {{
            width: 100% !important;
            color: var(--input-text) !important;
            background: var(--input-bg) !important;
            border: 1px solid var(--input-border) !important;
            border-radius: 12px !important;
            box-shadow: none !important;
            caret-color: var(--cyan) !important;
            transition: border-color .2s ease, box-shadow .2s ease, background .25s ease;
        }}

        div[data-testid="stForm"] input {{ min-height: 48px; }}
        div[data-testid="stForm"] textarea {{ min-height: 125px; }}

        div[data-testid="stForm"] input:focus,
        div[data-testid="stForm"] textarea:focus {{
            border-color: var(--cyan) !important;
            box-shadow: 0 0 0 3px color-mix(in srgb, var(--cyan) 12%, transparent) !important;
        }}

        div[data-testid="stForm"] input::placeholder,
        div[data-testid="stForm"] textarea::placeholder {{ color: var(--input-placeholder) !important; opacity: 1 !important; }}

        div[data-testid="stForm"] label,
        div[data-testid="stForm"] label p {{
            color: var(--muted) !important;
            font-weight: 600 !important;
            font-size: .82rem !important;
        }}

        div[data-testid="stForm"] [data-testid="stFormSubmitButton"] button {{
            min-height: 48px;
            border: 1px solid color-mix(in srgb, var(--cyan) 38%, transparent) !important;
            border-radius: 12px !important;
            background: linear-gradient(135deg, color-mix(in srgb, var(--cyan) 18%, transparent), color-mix(in srgb, var(--violet) 20%, transparent)) !important;
            color: var(--text) !important;
            font-weight: 700 !important;
            transition: .25s ease;
        }}

        div[data-testid="stForm"] [data-testid="stFormSubmitButton"] button:hover {{
            transform: translateY(-2px);
            border-color: var(--cyan) !important;
            box-shadow: 0 12px 30px color-mix(in srgb, var(--cyan) 13%, transparent);
        }}

        .footer {{ text-align: center; color: var(--muted); padding: 2.5rem 0 .5rem; font-size: .85rem; }}

        /* Streamlit status messages */
        [data-testid="stAlert"] {{ border-radius: 12px; }}

        .stButton > button, .stDownloadButton > button {{
            border-radius: 12px;
            border: 1px solid color-mix(in srgb, var(--cyan) 28%, transparent);
            background: linear-gradient(135deg, color-mix(in srgb, var(--cyan) 16%, transparent), color-mix(in srgb, var(--violet) 16%, transparent));
            color: var(--text);
            font-weight: 700;
            transition: .25s ease;
        }}

        .stButton > button:hover, .stDownloadButton > button:hover {{
            transform: translateY(-2px);
            border-color: color-mix(in srgb, var(--cyan) 55%, transparent);
            box-shadow: 0 10px 28px color-mix(in srgb, var(--cyan) 12%, transparent);
        }}

        @keyframes reveal {{ from {{ opacity: 0; transform: translateY(18px); }} to {{ opacity: 1; transform: translateY(0); }} }}
        @keyframes floatGlow {{ 0%, 100% {{ transform: translate(0,0) scale(1); }} 50% {{ transform: translate(-20px,20px) scale(1.08); }} }}
        @keyframes gradientText {{ 0% {{ background-position: 0% 50%; }} 100% {{ background-position: 220% 50%; }} }}

        @media (max-width: 768px) {{
            .block-container {{ padding-top: .8rem; }}
            .hero-card {{ padding: 1.5rem; }}
            .hero-name {{ font-size: 3rem; }}
            .project-image {{ height: 190px; }}
            .contact-shell {{ padding: 1.25rem; }}
        }}

        @media (prefers-reduced-motion: reduce) {{
            *, *::before, *::after {{
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                scroll-behavior: auto !important;
                transition-duration: .01ms !important;
            }}
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )
